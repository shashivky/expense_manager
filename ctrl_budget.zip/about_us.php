<?php
include'common.php';
?>

<!doctype html>
<!--This page can be accessed by both LOGGED In and LOGGED OUT users-->
<html>
    <head>
        <title> About Us | Ct₹l Budget</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/about_us.css">

    </head>

    <body>
        <!--Navigation bar-->
        <div><?php
            include'navbar_home.php';
            ?></div>

        <!--Navigation bar End-->

        <!--Main content of the page-->
        <div class="container-fluid content">
            <div class="container">
                <div class="row">
                    <div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-0">
                        <h4>Who are we?</h4>
                        <p>We are a group of youg technocrats who came up with an idea of solving budget and <br>
                            time issues which we usually face in our daily lives. We are here to provide a budget<br>
                            controller according to your aspects.</p>
                        <p>Budget control is the biggest financial issue in the present world. One should look after<br>
                            their budget control to get rid off from their financial crisis</p><br>
                    </div>
                    <div class="col-xs-10 col-xs-offset-1 col-sm-6 col-sm-offset-0">
                        <h4>Why choose us?</h4>
                        <p>We provide with a predominant way to control and manage your budget estimations with<br>
                            ease of accessing for multiple users.</p>
                    </div>
                </div>
            </div>

            <div class="container content_contact">
                <div class="row">
                    <div class="col-xs-10 col-xs-offset-1 col-sm-12 col-sm-offset-0">
                        <h4>Contact Us</h4>
                        <p><b>Email:</b> support@ctrlbudget.com</p>
                        <p><b>Mobile:</b> +91-8448444853</p>
                    </div>

                </div>
            </div>

            <!--Main content of the page END-->

            <!--Footer Section-->
            <div class="footer"> 
                <?php
                include'footer.php';
                ?>
            </div>
            <!--Footer End-->
        </div>
    </body>
</html>


