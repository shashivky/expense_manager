<?php
include'common.php';
//Ensuring the session variable is set and user is logged in,else the user is redirected to index page
if (isset($_SESSION['user'])) {

    //Select query to browse saved data from plan table to be displayed in panels 

    $select_query = "SELECT * FROM plan WHERE user_id='" . $_SESSION['user'] . "' ORDER BY plan_id DESC";
    $select_query_result = mysqli_query($con, $select_query);
    $num_rows = mysqli_num_rows($select_query_result);

    /* On the click of 'view plan button', the value of the button is stored as session variable.
      The value of button is associated with the plan_id of the corresponding plan.
      This value identifies the plan uniquely from the database and displays the result in 'view plan' page. */

    if (isset($_POST['view_plan'])) {
        $plan_num = $_POST['view_plan'];
        $_SESSION['plan_id'] = $plan_num;
        echo"<script>location.href='view_plan_page.php'</script>";
    }
} else {
    echo"<script>location.href='user_index.php'</script>";
}
?>
<!doctype html>
<!--This page can be accessd only by LOGGED in users-->
<html>
    <head>
        <title>HOME | Ct₹l Budget</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/user_home.css">
    </head>


    <body>
        <!-- NAVIGATION BAR -->
        <?php
        include'navbar_home.php';
        ?>
        <!-- NAVIGATION BAR ENDS -->

        <!-- User homepage is divided into two parts-->

        <!-- PART 1-CREATE PLAN: If a user is logged in AND does not have any plan in database, 
        he is shown a message 'You don't have any active plans' and a 'Create New Plan' button -->

        <!-- PART 2-ACTIVE PLANS: If a user is logged in AND has atleast one plan in database,
        Brief plan details are displayed to the user in panels -->

        <!-- PART 1: 'CREATE PLAN' BEGINS  -->
        <?php if (isset($_SESSION['user'])) { ?>
            <div class="container-fluid" style="margin-bottom:50px;">
                <div class="container-fluid">

                    <?php if ($num_rows == 0) { ?>
                        <div class="container">
                            <div class="row">
                                <div class="col-xs-12">
                                    <h2>You don't have any active plans </h2> </div>
                            </div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1">
                                        <div class="container create-plan">
                                            <a href="add_new_plan.php" class="link" style="text-decoration: none;"><span class="glyphicon glyphicon-plus-sign span-plus"></span> Create a New Plan</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    <?php } else { ?> 
                    </div>

                    <!-- PART 1 ENDS -->

                    <!-- PART 2:'ACTIVE PLANS' BEGINS -->
                    <div class="container" style="margin-top:20px;">
                        <h3>Your Plans</h3>
                        <div class="row">
                            <?php while ($user_array = mysqli_fetch_array($select_query_result)) { ?>
                                <div class="col-sm-4 col-sm-offset-0 col-md-3 col-md-offset-0">
                                    <div class="panel">
                                        <div class="panel-heading">
                                            <div class="row">
                                                <div class="col-xs-8">
                                                    <h4 style="text-align:center;"><?php echo $user_array['title'] ?></h4>
                                                </div>
                                                <div class="col-xs-4">
                                                    <div class="value">
                                                        <h4><span class="glyphicon glyphicon-user" style="font-size:20px;"></span> <?php echo $user_array['num_people']; ?></h4>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="col-xs-6">
                                                    <p><b>Budget</b></p>
                                                </div>
                                                <div class="col-xs-6">
                                                    <div class="value">
                                                        <p><span>&#8377</span> <?php echo $user_array['in_bdgt'] ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-2">
                                                    <p><b>Date</b></p>
                                                </div>
                                                <div class="col-xs-10">
                                                    <div class="value">
                                                        <p><?php
                                                            $date = date_create($user_array['date_from']);
                                                            echo date_format($date, "dS M");
                                                            ?> - <?php
                                                            $date = date_create($user_array['date_to']);
                                                            echo date_format($date, "dS M Y");
                                                            ?>  </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <form action="" method="POST"><button type="submit" class=" button btn-block" name="view_plan" value="<?php echo$user_array['plan_id']; ?>">View Plan</button></form> 
                                        </div>
                                    </div>
                                </div>

                            <?php } ?>   
                        </div>
                    </div>    
                    <div class="create-button">
                        <a href="add_new_plan.php"><span class="glyphicon glyphicon-plus-sign create"></span></a>
                    </div>
                <?php } ?> 
                <!-- PART 2 ENDS -->

            </div>        

            <!-- FOOTER SECTION -->
            <div class="footer">
                <?php
                include'footer.php';
                ?>   
            </div> 
            <!-- FOOTER SECTION ENDS -->

        <?php } ?> 
    </body>
</html>
