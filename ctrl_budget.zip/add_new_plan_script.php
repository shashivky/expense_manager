<?php

include'common.php';

//On the click of 'NEXT' button in 'create plan' form, the user's input are saved in suitable session variables
/* These session variables are used in the 'plan details' page to be displayed in appropriate form fields 
 * and generate required number of person fields */
if (!isset($_SESSION['user'])) {
    echo"<script>location.href='user_index.php'</script>";
} else {
    if (isset($_POST['next'])) {
        $_SESSION['people'] = mysqli_real_escape_string($con, $_POST['people']);
        $_SESSION['budget'] = mysqli_real_escape_string($con, $_POST['budget']);
        echo"<script>location.href='plan_details.php'</script>";
    }
}
?>

