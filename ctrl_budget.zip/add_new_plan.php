<?php
include'common.php';
?>
<?php
//Ensuring the page can be accessed only by LOGGED IN users
if (!isset($_SESSION['user'])) {
    echo"<script>location.href='user_index.php'</script>";
} else {
    ?>
    <!doctype html>
    <!-- This page can be accessed only by LOGGED IN users, otherwise the user is redirected to index page -->
    <html>
        <head>
            <title>Add Plan | Ct₹l Budget</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/add_new_plan.css">
        </head>

        <body>
            <!-- NAVIGATION BAR -->
            <div><?php
                include'navbar_home.php';
                ?></div>
            <!-- NAVIGATION BAR ENDS -->

            <!-- MAIN CONTENT -->
            <div class="container content">
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">

                        <!-- PANEL OPEN TO CONTAIN CREATE NEW PLAN FORM -->
                        <div class="panel">
                            <div class="panel-heading">
                                <h4>Create New Plan</h4>

                            </div>
                            <div class="panel">
                                <div class="panel-body">

                                    <!-- CREATE NEW PLAN FORM-->
                                    <!-- The inputs in the form by the user are processed in 'add_new_plan_script.php page' -->
                                    <form method="POST" action="add_new_plan_script.php">

                                        <div class="form-group">
                                            <label for="in_bdgt">Initial Budget:</label>
                                            <input type="number" class="form-control" id="in_bdgt" name="budget" step="0.01" required="true" placeholder="Initial Budget (Ex. 4000)" min="50">                    
                                        </div>

                                        <div class="form-group">
                                            <label for="people">How many people you want to add in your group:</label>
                                            <input type="number" class="form-control" id="people" name="people" required="true" placeholder="No. of people" min="1">                      
                                        </div>

                                        <button class="button btn-block" name="next"><b>Next</b></button>
                                    </form>
                                    <!-- CREATE NEW PLAN FORM ENDS-->

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="footer">
                <?php
                include'footer.php';
                ?>
            </div>
        </body>
    </html>
<?php } ?>