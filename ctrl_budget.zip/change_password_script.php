<?php

include'common.php';
/* Ensuring the session variables are set
  The user is identified by $_SESSION['user'] variable
  Update query is run against the user_id whose value mathces the $_SESSION['user'] in 'users' table
 */

if (!isset($_SESSION['user'])) {
    echo"<script>location.href='user_index.php'</script>";
} else {
    if (isset($_POST['change'])) {

        //Fetching the user's input from 'Change Password form' and Storing them in suitable variables
        $old_pwd = md5(md5($_POST['old_pwd']));
        $new_pwd = md5(md5($_POST['new_pwd']));
        $cnfm_new_pwd = md5(md5($_POST['cnfm_new_pwd']));

        //Fetching password corresponding to the active user from the users table
        $select_pwd_query = "Select password FROM users where user_id='" . $_SESSION['user'] . "' Limit 1";
        $select_pwd_query_result = mysqli_query($con, $select_pwd_query);
        $user_password = mysqli_fetch_array($select_pwd_query_result);
        $user_pwd = $user_password['password']; //The password corresponding to the active user is stored in '$user_pwd' variable.
        //
        //Running check to ensure old password from the user's input and $user_pwd match.
        if ($old_pwd != $user_pwd) {
            echo"<script>alert('Wrong old password')</script>";
            echo"<script>location.href='change_password.php'</script>";

            //Running check to ensure the passwords filled in both fields are equal
        } elseif ($new_pwd != $cnfm_new_pwd) {
            echo"<script>alert('Password do not match')</script>";
            echo"<script>location.href='change_password.php'</script>";

            //Running check to ensure the password filled is of minimum 6 characters length
        } else {
            //All the conditions are checked and satisfied
            //Updating the password in the users table
            $cnfm_new_pwd= mysqli_real_escape_string($con,$cnfm_new_pwd);
            $update_query = "UPDATE users SET password='" . $cnfm_new_pwd . "' WHERE user_id='" . $_SESSION['user'] . "'";
            $update_query_result = mysqli_query($con, $update_query);
            echo"<script>alert('Password Updated')</script>"; //Success message is displayed on Successful Update Query
            echo"<script>location.href='logout_script.php'</script>"; //User is redirected to logout page and finally to index page
        }
    }
}
?>
