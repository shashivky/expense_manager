<?php

include'common.php';
//Ensuring session is started and session variable is set,else the user is redirected to login page
if (isset($_SESSION['user'])) {
    if (isset($_POST['add'])) {
        //Following codes are executed when the user clicks 'SUBMIT' button on add plan details page
        //Fetching user's input from 'plan details form' and storing them in suitable variables
        $title = mysqli_real_escape_string($con, $_POST['title']);
        $from = mysqli_real_escape_string($con, $_POST['from']);
        $to = mysqli_real_escape_string($con, $_POST['to']);
        $num_people = $_SESSION['people'];  //Number of people added by the user in plan is fetched from 'add plan' page through session variable
        $user_id = $_SESSION['user'];  //user id is stored as session variable when a user logs in
        $bdgt = $_SESSION['budget']; //Budget added by the user is fetched from 'add plan' page through session variable

        $person = $_POST['person']; //Each of the input in various person's fields is stored as an array

        foreach ($person as $key => $value) {
            $value = mysqli_real_escape_string($con, $value);
        }

        //insert plan query to store the user's input into 'plan' table of ctrlbudget database
        $insert_plan_query = "INSERT into plan(title,user_id,num_people,in_bdgt,date_from,date_to,remain_budget) values ('$title','$user_id','$num_people','$bdgt','$from','$to','$bdgt')";
        $insert_plan_query_result = mysqli_query($con, $insert_plan_query) or die(mysqli_error($con));
        $plan_id = mysqli_insert_id($con);

        //Saving the last plan_id inserted into 'plan' table of database as session variable
        $_SESSION['plan'] = $plan_id;
        $plan = $_SESSION['plan'];

        //Inserting the person's details added by user in 'plan details form' into 'person' table
        foreach ($person as $key => $value) {
            $insert_query = "INSERT into person(name,plan_id)values('$value','$plan')";
            $insert_query_result = mysqli_query($con, $insert_query) or die(mysqli_error($con));
        }

        //Inserting the person's details into 'exp_dbution' table to be used in 'expense distribution page'
        //This insertion is done to update the expense distribution amount of various contributors each time a user adds expense on 'view plan page'
        foreach ($person as $key => $value) {
            $insert_person_query = "INSERT into exp_dbution(name_person,plan_id,exp_db_amt)values('$value','$plan','0')";
            $insert_person_query_result = mysqli_query($con, $insert_person_query) or die(mysqli_error($con));
        }
        //On Successful insertion, success message is displayed on alert box
        echo"<script>alert('Your New Budget Planner Added Successfully')</script>";
        echo"<script>location.href='user_home.php'</script>";
    }
} else {
    echo"<script>location.href='user_index.php'</script>"; //NOT LOGGED IN Users are redirected to index page
}
?>

