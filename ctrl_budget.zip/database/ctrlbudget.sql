-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 01, 2020 at 05:07 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ctrlbudget`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE IF NOT EXISTS `bill` (
  `bill_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `exp_id` int(11) DEFAULT NULL,
  `tmp_name` varchar(100) DEFAULT NULL,
  `img_type` varchar(50) DEFAULT NULL,
  `img_name` varchar(100) DEFAULT NULL,
  `path` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`bill_id`),
  KEY `exp_id` (`exp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_id`, `name`, `exp_id`, `tmp_name`, `img_type`, `img_name`, `path`) VALUES
(1, 'Food bill.JPG', 1, 'C:wamp64	mpphp9500.tmp', 'image/jpeg', '29-06-2020-1593436987.jpg', 'img/29-06-2020-1593436987.jpg'),
(2, 'decor bill.JPG', 3, 'C:wamp64	mpphpF607.tmp', 'image/jpeg', '29-06-2020-1593439895.jpg', 'img/29-06-2020-1593439895.jpg'),
(3, 'Bus booking reciept.JPG', 5, 'C:wamp64	mpphpECA0.tmp', 'image/jpeg', '29-06-2020-1593441203.jpg', 'img/29-06-2020-1593441203.jpg'),
(4, 'science bill.JPG', 7, 'C:wamp64	mpphp6763.tmp', 'image/jpeg', '29-06-2020-1593448509.jpg', 'img/29-06-2020-1593448509.jpg'),
(5, 'fuel bill.JPG', 12, 'C:wamp64	mpphp6519.tmp', 'image/jpeg', '30-06-2020-1593502314.jpg', 'img/30-06-2020-1593502314.jpg'),
(6, 'birthday bill.JPG', 15, 'C:wamp64	mpphpCE7.tmp', 'image/jpeg', '30-06-2020-1593508976.jpg', 'img/30-06-2020-1593508976.jpg'),
(7, 'Canvas bill.JPG', 18, 'C:wamp64	mpphpDBA9.tmp', 'image/jpeg', '30-06-2020-1593509356.jpg', 'img/30-06-2020-1593509356.jpg'),
(8, 'decor bill.JPG', 21, 'C:wamp64	mpphp39CB.tmp', 'image/jpeg', '30-06-2020-1593509774.jpg', 'img/30-06-2020-1593509774.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
CREATE TABLE IF NOT EXISTS `expense` (
  `exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) DEFAULT NULL,
  `title` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `exp_amt` varchar(20) DEFAULT NULL,
  `person` varchar(30) DEFAULT NULL,
  `bill` tinyint(1) DEFAULT NULL,
  `path` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`exp_id`),
  KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`exp_id`, `plan_id`, `title`, `date`, `exp_amt`, `person`, `bill`, `path`) VALUES
(1, 1, 'Food', '2020-07-01', '450', 'Ram', 1, 'img/29-06-2020-1593436987.jpg'),
(2, 1, 'Bus Booking', '2020-07-01', '1200', 'Akshay', 0, NULL),
(3, 2, 'Room supplies', '2020-06-23', '2388', 'Pratima', 1, 'img/29-06-2020-1593439895.jpg'),
(4, 2, 'Photo frames', '2020-06-25', '1300', 'Rashmi', 0, NULL),
(5, 3, 'Bus Booking', '2020-06-24', '3600', 'Priya', 1, 'img/29-06-2020-1593441203.jpg'),
(6, 4, 'Thermocols', '2020-06-17', '170', 'Anand', 0, NULL),
(7, 4, 'Robot Kit', '2020-06-18', '1200', 'Wardhman', 1, 'img/29-06-2020-1593448509.jpg'),
(8, 1, 'Backpacks', '2020-07-08', '450.50', 'Shashank', 0, NULL),
(9, 1, 'Shopping', '2020-07-02', '1500', 'Ram', 0, NULL),
(10, 1, 'Hotel Booking', '2020-07-02', '1800', 'Ram', 0, NULL),
(11, 3, 'Shopping', '2020-06-25', '1200', 'Nandita', 0, NULL),
(12, 5, 'Fuel expense', '2020-07-02', '151.52', 'Awshesh', 1, 'img/30-06-2020-1593502314.jpg'),
(13, 5, 'Mess charge', '2020-07-02', '1200', 'Babuni', 0, NULL),
(14, 5, 'Grocery', '2020-07-03', '88', 'Shashank', 0, NULL),
(15, 6, 'Birthday cake', '2020-06-27', '1080', 'Anshuman', 1, 'img/30-06-2020-1593508976.jpg'),
(16, 6, 'Birthday Knife', '2020-06-27', '20', 'Anshuman', 0, NULL),
(17, 6, 'Birthday gift', '2020-06-27', '1550', 'Preeti', 0, NULL),
(18, 7, 'Canvas', '2020-06-22', '792', 'Khusboo', 1, 'img/30-06-2020-1593509356.jpg'),
(19, 7, 'Paint brush', '2020-06-19', '220', 'Anjani', 0, NULL),
(20, 7, 'Paint colors', '2020-06-23', '340', 'Vijay', 0, NULL),
(21, 9, 'Decor items', '2020-06-23', '2388.5', 'Pratima', 1, 'img/30-06-2020-1593509774.jpg'),
(22, 10, 'Jackets', '2020-06-27', '1400', 'Babuni', 0, NULL),
(23, 10, 'Guide booking', '2020-06-27', '3200', 'Amar', 0, NULL),
(24, 5, 'Curtains', '2020-07-08', '140', 'Shashank', 0, NULL),
(25, 12, 'Tools', '2020-06-25', '800', 'Babuni', 0, NULL),
(26, 12, 'Labour', '2020-06-26', '1000', 'Awdhesh', 0, NULL),
(27, 11, 'Tea bill', '2020-06-24', '45', 'Shashank', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `exp_dbution`
--

DROP TABLE IF EXISTS `exp_dbution`;
CREATE TABLE IF NOT EXISTS `exp_dbution` (
  `exp_dis_id` int(11) NOT NULL AUTO_INCREMENT,
  `exp_id` int(11) DEFAULT NULL,
  `plan_id` int(11) DEFAULT NULL,
  `name_person` varchar(30) DEFAULT NULL,
  `exp_db_amt` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`exp_dis_id`),
  KEY `exp_id` (`exp_id`),
  KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exp_dbution`
--

INSERT INTO `exp_dbution` (`exp_dis_id`, `exp_id`, `plan_id`, `name_person`, `exp_db_amt`) VALUES
(1, NULL, 1, 'Ram', '3750'),
(2, NULL, 1, 'Akshay', '1200'),
(3, NULL, 1, 'Shashank', '450.5'),
(4, NULL, 2, 'Pratima', '2388'),
(5, NULL, 2, 'Rashmi', '1300'),
(6, NULL, 3, 'Priya', '3600'),
(7, NULL, 3, 'Nandita', '1200'),
(8, NULL, 3, 'Nivedita', '0'),
(9, NULL, 4, 'Anand', '170'),
(10, NULL, 4, 'Wardhman', '1200'),
(11, NULL, 4, 'Riya', '0'),
(12, NULL, 5, 'Awshesh', '151.52'),
(13, NULL, 5, 'Shashank', '228'),
(14, NULL, 5, 'Babuni', '1200'),
(15, NULL, 6, 'Anshuman', '1100'),
(16, NULL, 6, 'Anuj', '0'),
(17, NULL, 6, 'Binod', '0'),
(18, NULL, 6, 'Preeti', '1550'),
(19, NULL, 7, 'Khusboo', '792'),
(20, NULL, 7, 'Anjani', '220'),
(21, NULL, 7, 'Vijay', '340'),
(22, NULL, 8, 'Anjani', '0'),
(23, NULL, 8, 'Priya', '0'),
(24, NULL, 8, 'Vijay', '0'),
(25, NULL, 8, 'Khusboo', '0'),
(26, NULL, 8, 'Anand', '0'),
(27, NULL, 8, 'Chandan', '0'),
(28, NULL, 9, 'Vaishnavi', '0'),
(29, NULL, 9, 'Pratima', '2388.5'),
(30, NULL, 10, 'Babuni', '1400'),
(31, NULL, 10, 'Santosh', '0'),
(32, NULL, 10, 'Amar', '3200'),
(33, NULL, 10, 'Kundan', '0'),
(34, NULL, 11, 'Ram', '0'),
(35, NULL, 11, 'Shashank', '45'),
(36, NULL, 11, 'Akshay', '0'),
(37, NULL, 12, 'Babuni', '800'),
(38, NULL, 12, 'Awdhesh', '1000'),
(39, NULL, 12, 'Shashank', '0'),
(40, NULL, 13, 'Akshay', '0'),
(41, NULL, 13, 'Shashank', '0'),
(42, NULL, 14, 'Nivedita', '0'),
(43, NULL, 14, 'Arpita', '0');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
CREATE TABLE IF NOT EXISTS `person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  KEY `plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`person_id`, `plan_id`, `name`) VALUES
(1, 1, 'Ram'),
(2, 1, 'Akshay'),
(3, 1, 'Shashank'),
(4, 2, 'Pratima'),
(5, 2, 'Rashmi'),
(6, 3, 'Priya'),
(7, 3, 'Nandita'),
(8, 3, 'Nivedita'),
(9, 4, 'Anand'),
(10, 4, 'Wardhman'),
(11, 4, 'Riya'),
(12, 5, 'Awshesh'),
(13, 5, 'Shashank'),
(14, 5, 'Babuni'),
(15, 6, 'Anshuman'),
(16, 6, 'Anuj'),
(17, 6, 'Binod'),
(18, 6, 'Preeti'),
(19, 7, 'Khusboo'),
(20, 7, 'Anjani'),
(21, 7, 'Vijay'),
(22, 8, 'Anjani'),
(23, 8, 'Priya'),
(24, 8, 'Vijay'),
(25, 8, 'Khusboo'),
(26, 8, 'Anand'),
(27, 8, 'Chandan'),
(28, 9, 'Vaishnavi'),
(29, 9, 'Pratima'),
(30, 10, 'Babuni'),
(31, 10, 'Santosh'),
(32, 10, 'Amar'),
(33, 10, 'Kundan'),
(34, 11, 'Ram'),
(35, 11, 'Shashank'),
(36, 11, 'Akshay'),
(37, 12, 'Babuni'),
(38, 12, 'Awdhesh'),
(39, 12, 'Shashank'),
(40, 13, 'Akshay'),
(41, 13, 'Shashank'),
(42, 14, 'Nivedita'),
(43, 14, 'Arpita');

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

DROP TABLE IF EXISTS `plan`;
CREATE TABLE IF NOT EXISTS `plan` (
  `plan_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `in_bdgt` varchar(30) DEFAULT NULL,
  `num_people` int(15) DEFAULT NULL,
  `title` varchar(20) DEFAULT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `remain_budget` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`plan_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plan`
--

INSERT INTO `plan` (`plan_id`, `user_id`, `in_bdgt`, `num_people`, `title`, `date_from`, `date_to`, `remain_budget`) VALUES
(1, 1, '5000', 3, 'Kasauli Trip', '2020-06-30', '2020-07-10', '-400.5'),
(2, 2, '4500', 2, 'Room Decor', '2020-06-20', '2020-06-27', '812'),
(3, 3, '12000', 3, 'Kasauli Trip', '2020-06-23', '2020-07-02', '7200'),
(4, 4, '2500', 3, 'Science Project', '2020-06-15', '2020-06-20', '1130'),
(5, 1, '5000', 3, 'Monthly expense', '2020-07-01', '2020-07-15', '3420.48'),
(6, 6, '6500', 4, 'Birthday party', '2020-06-27', '2020-06-28', '3850'),
(7, 8, '3500', 3, 'Art Fair', '2020-06-19', '2020-06-24', '2148'),
(8, 8, '4500', 6, 'Pizza treat', '2020-06-25', '2020-06-27', '4500'),
(9, 9, '5000', 2, 'Room decor', '2020-06-20', '2020-06-25', '2611.5'),
(10, 10, '10000', 4, 'Trekking', '2020-06-27', '2020-06-30', '5400'),
(11, 1, '252', 3, 'Tea Treat', '2020-06-24', '2020-06-25', '207'),
(12, 10, '2300', 3, 'Repair task', '2020-06-25', '2020-06-30', '500'),
(13, 1, '250', 2, 'CCD', '2020-06-25', '2020-06-29', '250'),
(14, 13, '3300', 2, 'House warming', '2020-07-02', '2020-07-10', '3300');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `phone`, `password`) VALUES
(1, 'shashank kumar', 'shashankvky@gmail.com', '8294581106', 'd99d94a868a66f5b7be62fa879cb4af6'),
(2, 'Pratima Gandhi', 'pratimagandhi@gmail.com', '8987656543', '62c18704a4dc49063c77a14acca1827c'),
(3, 'Priya Santosh', 'priyasantosh@gmail.com', '7765468901', 'df70cb72ea35dffe9c0a7c984e69273c'),
(4, 'Anand raj', 'anand1995@gmail.com', '6968300278', '0cf5fe59eec6cb6a51740d983f1e807e'),
(5, 'Mahesh Ranjan', 'maheshranjan@gmail.com', '8294581106', '6e65d6210a1d0327caebd5ccb3ead3bc'),
(6, 'Vishnu Khanna', 'vishnukhanna@gmail.com', '9876543456', 'e1c08b62375a5615d792c00e51583e24'),
(7, 'Anshuman', 'anshuman@gmail.com', '7865434567', 'df9192785ffc7844010a2ab2a4a97973'),
(8, 'Anjani Murmu', 'anjanimurmu@yahoo.com', '8765003427', 'af7a86eab6c43baa5e58b8e41a40bd92'),
(9, 'Vaishnavi Sharma', 'vaishnavi@gmail.com', '6998750048', '31155fc8a51f21a3931eaf9aca773903'),
(10, 'Babuni Prasad', 'babunibinay@gmail.com', '8798765456', 'a19fdef99cf7b5a654db97d526a1e78e'),
(11, 'shashank kumar', 'nehamehta@gmail.com', '8294581106', 'ec6a6536ca304edf844d1d248a4f08dc'),
(12, 'Sadaf', 'sadaf@gmail.com', '8294581106', 'ec6a6536ca304edf844d1d248a4f08dc'),
(13, 'Nivedita', 'nivedita@gmail.com', '9765467890', 'af200568279f0147401d287f75d5ccc2');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill`
--
ALTER TABLE `bill`
  ADD CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`exp_id`) REFERENCES `expense` (`exp_id`);

--
-- Constraints for table `expense`
--
ALTER TABLE `expense`
  ADD CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`);

--
-- Constraints for table `exp_dbution`
--
ALTER TABLE `exp_dbution`
  ADD CONSTRAINT `exp_dbution_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`);

--
-- Constraints for table `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `person_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`);

--
-- Constraints for table `plan`
--
ALTER TABLE `plan`
  ADD CONSTRAINT `plan_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
