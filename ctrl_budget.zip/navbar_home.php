<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <body>

        <nav class="navbar navbar-inverse navbar-fixed">
            <div class="container">
                <!-- HEADER Section to contain LOGO of the website -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                    </button>
                    <a class="navbar-brand" href="user_home.php" >Ct<span>&#8377</span>l Budget</a>
                </div>
                <!-- HEADER Section Ends -->

                <!-- LINK Section to contain different Links of the website -->
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <?php if (isset($_SESSION['user'])) {
                            ?> 
                            <li><a href = "about_us.php"><span class = "glyphicon glyphicon-info-sign"></span> About Us </a></li> 
                            <li><a href = "change_password.php"><span class = "glyphicon glyphicon-cog"></span> Change Password</a></li> 
                            <li><a href = "logout_script.php"><span class = "glyphicon glyphicon-log-in"></span> Logout</a></li>

                            <?php
                        } else {
                            ?> 
                            <li><a href = "about_us.php"><span class = "glyphicon glyphicon-info-sign"></span> About Us </a></li> 
                            <li><a href="user_signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li> 
                            <li><a href="user_login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> 
                                <?php
                            }
                            ?>
                    </ul>
                </div>
                <!-- LINK section ends -->
            </div>
        </nav> 
    </body>
</html>
