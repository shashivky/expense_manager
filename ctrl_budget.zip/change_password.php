<?php
include'common.php';
?>
<?php
//Ensuring the user is LOGGED IN to access this page, else he is redirected to index page
if (!isset($_SESSION['user'])){
    echo"<script>location.href='user_index.php'</script>";
}else{
?>
<!doctype html>
<!-- This page can be accessed only by LOGGED IN users, otherwise the user is redirected to index page -->
<html>
    <head>
        <title>Change Password | Ct₹l Budget</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/change_password.css">

    </head>
    <body>  
         <!-- NAVIGATION SECTION-->
        <?php
        include'navbar_home.php'
        ?>
          <!-- NAVIGATION BAR SECTION ENDS-->
          
        <div class="container content">
            <div class="row">
              
            <div class="col-sm-4 col-sm-offset-4">
               
                <!-- PANEL OPEN TO CONTAIN CHANGE PASSWORD FORM -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4>Change Password</h4>
                    </div>
                    <div class="panel-body">
                        
                        <!--CHANGE PASSWORD FORM -->
                        <form method="POST" action="change_password_script.php">
                            <!-- The user's input in this form is processed in 'change_password_script.php' page -->
                            
                            <div class="form-group">
                                <label for="old_pwd">Old Password</label>
                                <input type="password" class="form-control" id="old_pwd" name="old_pwd" placeholder="Old Password" required="true">
                            </div>

                            <div class="form-group">
                                <label for="new_pwd">New Password</label>
                                <input type="password" class="form-control" id="new_pwd" name="new_pwd" placeholder="New Password (Min. 6 characters)" required="true" pattern=".{6,}">
                            </div>

                            <div class="form-group">
                                <label for="cnfm_new_pwd">Confirm New Password</label>
                                <input type="password" class="form-control" id="cnfm_new_pwd" name="cnfm_new_pwd" placeholder="Re-type New Password" required="true" pattern=".{6,}">
                            </div>

                            <button type="submit" class="button btn-block" name="change">Change</button>
                        </form>
                        <!-- CHANGE PASSWORD FORM ENDS-->
                    </div>
                </div>
                <!-- PANEL ENDS -->
                
            </div>
        </div>
        </div>
    
    <!-- FOOTER SECTION-->
        <div class="footer">
            <?php
            include'footer.php'
            ?>
        </div>  
     <!-- FOOTER SECTION ENDS-->
    </body>
</html>
<?php } ?>
