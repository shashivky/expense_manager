
<?php
include'common.php';
/* Ensuring the session variables are set
  The user is identified by the set session variable '$_SESSION['user']' which stores the value of 'user_id' of 'user' from 'users' table
  The plan of the user is identified by the set session variable '$_SESSION['plan_id'] which stores the value of 'plan_id' from 'plan' table
 */
if (isset($_SESSION['user']) && isset($_SESSION['plan_id'])) {

    /* Fetching plan details of the user from the plan table of database 
      These details are displayed in a panel in 'View Plan Section'
     */
    $select_plan_query = "SELECT title,in_bdgt,num_people,date_from,date_to,remain_budget FROM plan WHERE user_id='" . $_SESSION['user'] . "' AND plan_id='" . $_SESSION['plan_id'] . "'";
    $select_plan_query_result = mysqli_query($con, $select_plan_query);

    /* Storing the fetched values from plan table by '$select_plan_query' in an array 
      These values are stored in array beacuase they are required to be used multiple times in the page
     */
    $result = array();
    while ($row = mysqli_fetch_array($select_plan_query_result)) {
        $result[] = $row;
    }

    /* Details of the person(contributors in expense) added by the user in 'plan-details page' is fetched from 'person' table
      These values are used to create options in 'Choose' field in the 'Add expense form'
     */
    $select_person_query = "SELECT person_id,name FROM person WHERE plan_id='" . $_SESSION['plan_id'] . "'";
    $select_person_query_result = mysqli_query($con, $select_person_query);
    $num_rows_people = mysqli_num_rows($select_person_query_result);

    /* The details of expense added by the user is fetched from the expense table 
      These details are displayed in various 'Expenses Cards'
      Data saved in bill and path columns are used to display bill details in 'Expense Cards'
     */
    $select_expense_query = "SELECT exp_id,exp_amt,title,date,person,bill,path FROM expense WHERE plan_id='" . $_SESSION['plan_id'] . "'";
    $select_expense_query_result = mysqli_query($con, $select_expense_query);
    $num_rows_exp = mysqli_num_rows($select_expense_query_result);
} else {
    echo"<script>location.href='user_index.php'</script>";
}
?>
<!doctype html>
<!-- This page can be accessed only by LOGGED IN users-->
<html>
    <head>
        <title>View Plan | Ct₹l Budget</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

        <link rel="stylesheet" type="text/css" href="css/view_plan_page.css">
    </head>
    <body>

        <!-- NAVIGATION BAR SECTION-->
        <?php
        include'navbar_home.php';
        ?>
        <!-- NAVIGATION BAR ENDS-->

        <!-- THIS PAGE IS DIVIDED INTO TOTAL 4 SECTIONS
        SECTION 1: VIEW PLAN SECTION
        SECTION 2: EXPENSE DISTRIBUTION BUTTON SECTION
        SECTION 3: EXPENSE CARDS SECTION
        SECTION 4: ADD EXPENSE FORM SECTION
        
        SECTION 1 and SECTION 2 are in first row(PART A) of the page
        SECTION 3 and SECTION 4 are in second row(PART B) of the page
        -->
        <!-- PART A BEGINS -->
        <div class="container content">
            <div class="container">
                <div class="row">

                    <!--SECTION 1: VIEW PLAN SECTION BEGINS -->
                    <!-- 
                    In this section the user's plan details corresponding to the plan he choose in users_home page are displayed in a panel.
                    The plan is identified by the respective plan_id which is retrieved from the value of 'view plan' button 
                    in the user's home page and stored as session variable.
                    -->
                    <div class="col-sm-6 col-sm-offset-0 col-xs-offset-0">

                        <?php foreach ($result as $key => $array) { ?>
                            <div class="panel">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-8 col-xs-offset-1">
                                            <h4><?php echo $array['title'] ?></h4>
                                        </div>
                                        <div class="col-xs-3">
                                            <div style="float:right;"><h4><span class="glyphicon glyphicon-user"></span> <?php echo $array['num_people']; ?></h4></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">

                                    <div class="row">
                                        <div class="col-xs-4 data">
                                            <p>Budget</p>
                                        </div>
                                        <div class="col-xs-8">
                                            <div class="value"> <p><span>&#8377</span> <?php echo $array['in_bdgt']; ?></p></div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-6 data">
                                            <p>Remaining amount</p>
                                        </div>
                                        <div class="col-xs-6">
                                            <div class="value"><?php
                                                $remaining_budget = $array['remain_budget'];
                                                if ($remaining_budget >= 0) {
                                                    ?>
                                                    <div><p style="color:green;"><span>&#8377</span> <?php echo $remaining_budget ?></p></div>
                                                <?php } else { ?>
                                                    <div  style="color:rgb(255,0,0);"><p><b>Overspent by <span>&#8377</span> <?php echo -$remaining_budget ?></b></p></div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-xs-4 data">
                                            <p>Date</p>
                                        </div>
                                        <div class="col-xs-8">
                                            <div class="value"><p><?php
                                                    $date = date_create($array['date_from']);
                                                    echo date_format($date, "dS M")
                                                    ?> - <?php
                                                    $date = date_create($array['date_to']);
                                                    echo date_format($date, "dS M Y");
                                                    ?></p></div>
                                        </div>
                                    </div>


                                </div>
                            </div> 
                        <?php } ?>
                    </div>
                    <!-- VIEW PLAN SECTION ENDS-->

                    <!-- SECTION 2: EXPENSE DISTRIBUTION BUTTON SECTION BEGINNING -->

                    <!-- This section consists of a button 'EXPENSE DISTRIBUTION' which redirects the user to 'expense distribution page' --> 

                    <div class="col-sm-4 col-sm-offset-2 col-xs-12 col-xs-offset-0">
                        <div class="expense">
                            <a href="exp_distribution.php" class="button">Expense Distribution</a>
                        </div>
                    </div> 
                    <!-- EXPENSE DISTRIBUTION BUTTON SECTION END-->
                </div>
            </div>
            <!-- PART A ENDS -->
            
            <!-- PART B BEGINS -->
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-0 col-xs-10 col-xs-offset-1">

                        <!-- SECTION 3:  EXPENSE CARD SECTION BEGINS -->
                        
                        <!-- In this section, the expense added by the user is displayed in panels. The expense details 
                        are fetched from the 'expense' table corresponding to the respective plan id of the user
                        -->

                        <div class="row">
                            <?php while ($expense = mysqli_fetch_array($select_expense_query_result)) { ?>
                                <div class=" col-sm-6 col-sm-offset-0 col-xs-12 col-xs-offset-0">
                                    <div class="panel">
                                        <div class="panel-heading">
                                            <div class="row">
                                                <div>
                                                    <h4><?php echo $expense['title']; ?></h4>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="col-xs-6 data">
                                                    <p>Amount</p>
                                                </div>
                                                <div class="col-xs-6">
                                                    <div class="value"><p><span>&#8377</span> <?php echo $expense['exp_amt']; ?></p></div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-6 data">
                                                    <p>Paid by</p>
                                                </div>
                                                <div class="col-xs-6">
                                                    <div class="value"> <p><?php echo $expense['person']; ?></p></div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-4 data">
                                                    <p>Paid on</p>
                                                </div>
                                                <div class="col-xs-8">
                                                    <div class="value"><p><?php
                                                            $date = date_create($expense['date']);
                                                            echo date_format($date, "dS M -Y");
                                                            ?></p></div>
                                                </div>
                                            </div>
                                            <div class="row">

                                                <div class="col-xs-12">
                                                    <center>
                                                        <?php if ($expense['bill'] == 0) { ?><p>You don't have bill</p> <?php } else {
                                                            ?><p><a href="<?php echo$expense['path'] ?>" target="_blank" style="text-decoration:none;">Show bill</a></p> <?php } ?>
                                                    </center>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    


                                </div>
                            <?php } ?>
                        </div>

                    </div>
                    <!-- EXPENSE CARD SECTION ENDS -->


                    <!-- SECTION 4: ADD EXPENSE FORM START--> 
                    <!-- This section consists of a form inside a panel which is used to add expense by the user corresponding to the plan_id. 
                    The input of the user is processed in 'add_expense_script.php page' and the data is stored in 'expense' table in 
                    the data base-->
                    <div class="col-sm-4 col-sm-offset-2 col-xs-12 col-xs-offset-0">
                        <div class="panel">
                            <div class="panel-heading">
                                <h4>Add New Expense</h4>
                            </div>
                            <div class="panel-body">
                                <form method="POST" action="add_expense_script.php" enctype="multipart/form-data">

                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" class="form-control" id="title" name="title" placeholder="Expense name" required="true">
                                    </div>

                                    <div class="form-group">
                                        <label for="date">Date</label>
                                        <input type="date" class="form-control" id="date" name="date" min="<?php
                                        foreach ($result as $key => $array)
                                            echo $array['date_from']
                                            ?>" max="<?php
                                               foreach ($result as $key => $array)
                                                   echo $array['date_to']
                                                   ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="amt_spent">Amount spent</label>
                                        <input type="number" class="form-control" id="amt_spent" name="amt_spent" placeholder="Amount spent" step="0.01" required="true" min="0">
                                    </div>
                                    <select name="person" class="form-control" required="true">
                                        <option value="" disabled selected hidden>Choose</option>
                                        <?php while ($name = mysqli_fetch_array($select_person_query_result)) { ?>
                                            <option><?php echo $name['name'] ?> </option>
                                        <?php } ?>
                                    </select>


                                    <div class="form-group">
                                        <label for="upload">Upload Bill</label>
                                        <input type="file" class="form-control" id="upload" name="file">
                                    </div>      
                                    <button type="submit" class="button_add btn-block" name="add">Add</button>
                                </form>
                            </div>

                        </div>   
                    </div>
                </div>
            </div
            <!-- PART B ENDS -->
        </div>
        <!-- FOOTER SECTION -->
        <div class="footer">
            <?php
            include'footer.php';
            ?>   
        </div> 
        <!-- FOOTER SECTION ENDS -->
    </body>
</html>
