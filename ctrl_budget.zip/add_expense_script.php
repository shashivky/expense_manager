<?php

include'common.php';

//Function to upload file
function GetImageExtension($imagetype) {
    if (empty($imagetype))
        return false;
    switch ($imagetype) {
        case 'image/bmp' : return '.bmp';
        case 'image/gif' : return '.gif';
        case 'image/jpeg' : return '.jpg';
        case 'image/png' : return '.png';
        default : return false;
    }
}

//Ensuring session variable is set,else the user is redirected to home page
//The user is identified by '$_SESSION['user']' variable 
//The specific plan of the user across different table is identified by '$_SESSION['plan_id']' variable
if (isset($_SESSION['user'])) {
    if (isset($_POST['add'])) {
        //Following codes are executed when a user clicks the ADD button on 'Add Expense form' in 'view plan' page
        //Fetching details of the uploded file(bill) and saving them in suitable variables
        $file_name = $_FILES['file']['name'];
        $temp_name = $_FILES['file']['tmp_name'];
        $imgtype = $_FILES['file']['type'];
        $ext = GetImageExtension($imgtype);
        $imagename = date("d-m-Y") . "-" . time() . $ext;

        //Fetching data from user's input and storing them in suitable variables
        $title = mysqli_real_escape_string($con, $_POST['title']);
        $date = mysqli_real_escape_string($con, $_POST['date']);
        $amt_spent = mysqli_real_escape_string($con, $_POST['amt_spent']);
        $person = mysqli_real_escape_string($con, $_POST['person']);
        $plan_id = $_SESSION['plan_id']; /* plan_id corresponding to the plan the user is working upon, is fetched from the session variable 
         * when a user clicks 'view plan' button on 'user_home' page */

        /* Calculation of remaining amount from the budget 
          The default value of remaining amount is set equal to inital budget of the plan
          when a user creates a plan and enters its details on 'plan_details page' */
        $select_remaining_amount_query = "SELECT remain_budget FROM plan where plan_id='" . $plan_id . "' Limit 1";
        $select_remaining_amount_query_result = mysqli_query($con, $select_remaining_amount_query);
        $remaining_amount_array = mysqli_fetch_array($select_remaining_amount_query_result);
        $remaining_amount = $remaining_amount_array['remain_budget'];
        $remaining_amount = $remaining_amount - $amt_spent;

        //Updating the value of remaining amount in 'plan' table
        //This value is updated in the plan table each time the user adds an expense
        $update_remaining_amount_query = "UPDATE plan SET remain_budget='" . $remaining_amount . "' WHERE plan_id='" . $plan_id . "'";
        $update_remaining_amount_query_result = mysqli_query($con, $update_remaining_amount_query);

        //Inserting expense details from the user's input in 'Add expense form' into 'expense' table
        $insert_expense_query = "INSERT into expense (plan_id,title,date,exp_amt,person,bill) values('$plan_id','$title','$date','$amt_spent','$person','0')";
        $insert_expense_query_result = mysqli_query($con, $insert_expense_query)or die(mysqli_error($con));
        $exp_id = mysqli_insert_id($con);

        //Saving bill details in 'bill' table
        if (isset($file_name) and ! empty($file_name)) {
            $target_path = "img/" . $imagename;
            if (move_uploaded_file($temp_name, $target_path)) {
                $insert_bill_query = "INSERT into bill(name,exp_id,tmp_name,img_type,img_name,path) values('$file_name','$exp_id','$temp_name','$imgtype','$imagename','$target_path')";
                $insert_bill_query_result = mysqli_query($con, $insert_bill_query);

                /* Updating bill details in 'expense' table if a user chose to upload a bill
                  These details are used in 'view plan page' to display bill information in 'Expense cards' */
                $update_bill_query = "UPDATE expense set bill='1' WHERE exp_id='" . $exp_id . "'";
                $update_bill_query_result = mysqli_query($con, $update_bill_query);
                $update_bill_path_query = "UPDATE expense set path='" . $target_path . "' WHERE exp_id='" . $exp_id . "'";
                $update_bill_path_query_result = mysqli_query($con, $update_bill_path_query);
            }
        }

        /* Calculation of amount spent by an individual contributor to the plan 
          The default value of exp_db_amt(expense-distribution-amount) is set to '0' when a user adds persons in 'plan details page' */
        $select_exp_amt_query = "SELECT exp_db_amt FROM exp_dbution WHERE name_person='" . $person . "' AND plan_id='" . $plan_id . "'";
        $select_exp_amt_query_result = mysqli_query($con, $select_exp_amt_query);
        $amount = mysqli_fetch_array($select_exp_amt_query_result);
        $amt = $amount['exp_db_amt'];
        $amt = $amt_spent + $amt;

        /* Updating the value of expense by an individual user in 'exp_dbution' table
          This value is updated in the 'exp_dbution' table each time the user adds expense */
        $update_exp_db_query = "UPDATE exp_dbution SET exp_db_amt='" . $amt . "' WHERE name_person='" . $person . "' AND plan_id='" . $plan_id . "'";
        $update_exp_db_query_result = mysqli_query($con, $update_exp_db_query);

        //On Successful addition of the expense, the user is redirected back to 'view_plan_page.php'
        echo"<script>location.href='view_plan_page.php'</script>";
    }
} else {

    echo"<script>location.href='user_index.php'</script>"; //Not logged in user is redirected to index page
}
?>