<?php

include'common.php';
//When a user input data into form-fields of 'Sign up' form, the input data are processed through following codes:
if (isset($_POST['register'])) {

//Fetching data from user's input and storing them in suitable variables
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $em = mysqli_real_escape_string($con, $_POST['email']);
    $pwd = $_POST['password'];
    $phone = mysqli_real_escape_string($con, $_POST['phone']);

//Ensuring Password is minimum 6 characters long
    if (strlen($pwd) < 6) {
        echo"<script>alert('Minimum 6 digits required')</script>";
        echo"<script>location.href='user_signup.php'</script>";
    }
//Ensuring phone number is of 10 digit
    elseif ((strlen($phone) != 10)) {
        echo"<script>alert('Not a valid phone number')</script>";
        echo"<script>location.href='user_signup.php'</script>";
    }

//Browsing email from database to check if the input email already exists
    else {
        $select_query = "SELECT email FROM users WHERE email='$em'";
        $select_query_result = mysqli_query($con, $select_query);
        $rows = mysqli_num_rows($select_query_result);

//Ensuring the email is not already registered
        if ($rows != 0) {
            echo"<script>alert('You are already registered')</script>";
            echo"<script>location.href='user_signup.php'</script>";
        }
//Generating insert query and inserting user's data into 'users' table of ctrlbudget database
        else {
            //All the conditions are checked and user's details are verified
            //Encrypting the password
            $pwd = md5(md5($pwd));

            //Saving user's details into 'users' table of ctrlbudget database
            $insert_query = "INSERT into users(name,email,phone,password)values('$name','$em','$phone','$pwd')";
            $insert_query_result = mysqli_query($con, $insert_query)or die(mysqli_error($con));

            //Saving email and user_id inserted in last row of users table into Session variables to be used across different pages
            //User is identified uniquely by '$_SESSION['user'] variable
            $_SESSION['email'] = $em;
            $_SESSION['user'] = mysqli_insert_id($con);

            //On Successful registration, success message is displayed on alert box and user is redirected to home page
            echo"<script>alert('User Successfully registered')</script>";
            echo"<script>location.href='user_home.php'</script>";
        }
    }
}
?>