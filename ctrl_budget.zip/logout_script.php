<?php
include 'common.php';
session_unset();
session_destroy();
 echo"<script>location.href='user_home.php'</script>"
?>