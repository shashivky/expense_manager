<?php
include'common.php';
if (isset($_SESSION['user'])){
    echo"<script>location.href='user_home.php'</script>";
} else {
?>
<!doctype html>
<!-- This page can be accessed only by LOGGED OUT user -->
<html>
    <head>
        <title>Login | Ct₹lBudget</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/user_login.css">
    </head>
    
    <body>   
        <!--NAVIGATION BAR-->
        <div>
            <?php
            include'navbar_home.php';
            ?>
        </div>
        <!--NAVIGATION BAR ENDS-->   

        <div class="container content">
            <div class="row">
                <div class=" col-sm-4 col-sm-offset-4">

                    <!-- PANEL OPEN TO CONTAIN LOGIN FORM  -->

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4>LOGIN</h4>
                        </div>
                        <div class="panel-body">

                            <!-- LOGIN FORM  -->
                            <form method="POST" action="user_login_script.php">
                                <!-- The inputs in the login form are processed in 'user_login_script.php'  -->

                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="email" class="form-control" id="email" name="email" required="true" placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
                                </div>

                                <div class="form-group">
                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required="true" pattern=".{6,}" >

                                </div>
                                <button type="submit" class="button btn-block" name="login">Login</button>

                            </form>
                            <!-- LOGIN FORM END -->

                            <div class="panel-footer">
                                <h5>Don't have an account? <a href="user_signup.php" style="text-decoration:none;">Click here to Sign Up</a></h5>
                            </div>

                        </div>
                    </div> 
                    <!-- PANEL END  -->
                </div>
            </div>
        </div>
        <!-- FOOTER SECTION   -->  
        <div class="footer">
            <?php
            include'footer.php';
            ?>  
        </div>
        <!-- FOOTER SECTION ENDS  -->

    </body>
</html>
<?php } ?>