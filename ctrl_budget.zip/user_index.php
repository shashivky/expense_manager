<?php
if (isset($_SESSION['user'])){
    echo"<script>location.href='user_home.php'</script>";
}
else{
?>
<!doctype html>
<!-- This page can be accessed only by LOGGED OUT users -->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type=text/css href="css/user_index.css">
    </head>
    <body>
        <!-- NAVIGATION BAR SECTION -->
        <?php
        include'navbar_home.php';
        ?>
        <!-- NAVIGATION BAR SECTION ENDS -->
        
        <!-- CONTENT OF THE PAGE -->
        <div class="content">
                <div class = "banner-image">
                    <div class="inner-banner-image">	
                        <center>
                            <div class="banner-content">
                                <h1>We help control your budget</h1>
                                <br>
                                <a  href="user_login.php" class="button" style="text-decoration:none;">Start Today</a>
                            </div>
                        </center>
                    </div>
                </div>
            </div>
        <!-- CONTENT OF THE PAGE ENDS -->
        
        <!-- FOOTER SECTION BEGINS-->
        <div class="footer">
        <?php
        include'footer.php';
        ?>
        </div>
        <!-- FOOTER SECTION ENDS-->
    </body>
</html>
<?php } ?>