INTERSHALA WEB DEV BATTLE (14.05.2020 - 02.07.2020)
NAME - SHAHSANK KUMAR
EMAIL - shashankkumar.che19@itbhu.ac.in

STEPS TO RUN THE PROJECT

1. Extract all the files and folders in 'ctrlbudget.zip' folder on the computer

<--- CREATE DATABASE--->

2. RUN the WAMP SERVER.
3. OPEN phpmyadmin and create a database named 'ctrlbudget'.

4. IMPORT the 'ctrlbudget.sql' file present in 'database' folder of 'ctrlbudget.zip' file to add required 
   tables in the database.

<---PHP FILES AND FOLDERS --->

5. Open the 'www' folder in the WAMP server folder and COPY & PASTE 'bill' 'img' and 'css' 
   folder inside it.
6. MOVE all the 'php' files in 'www' folder of WAMP server
7. OPEN the browser(Google chrome is preferable) and type localhost/user_index.php
8. The index page is now opened

<---CONNECT THE DATABASE--->
1. OPEN the common.php file in a text-editor.
   The connection variable may require updates as required:
        Defualt connection variable: $con = mysqli_connect("localhost","root","","ctrlbudget","3306");

	a. Default value for username is set to "root" and default value for password is set to "" (blank). 
 	   Please update the values if some other values are set for the fields.
	b. The default port set is "3306". In case, the mysql server is running on a different port,
           Please update the port number.


<---FUNCTIONALITY--->
Once the index page is opened, CLICK 'START NOW' or 'LOGIN',

1. LOGIN With the following credential to see the added plans:
   
   Email: shashankvky@gmail.com
   Password: Shashank123

   OR
   
2. LOGIN with following credential to start from 'CREATE PLAN' section
   Email:maheshranjan@gmail.com
   Password: Mahesh123

   OR
   
3.CLICK on 'SIGNUP' and Sign up as NEW user.   
   