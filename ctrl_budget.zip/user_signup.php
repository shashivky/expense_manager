<?php
include'common.php';
//Logged in users cannot access this page
if(isset($_SESSION['user'])){
    echo"<script>location.href='user_home.php'</script>";
} else {
?>

<!doctype html>
<!-- This page can be accessed only by LOGGED OUT users, Logged in users will be redirected to home page-->
<html>
    <head>
        <title>SIGN UP | Ct₹l Budget</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/user_signup.css">
    </head>
    <body>
        <!-- NAVIGATION BAR -->
        <?php
        include'navbar_home.php';
        ?>
        <!-- NAVIGATION BAR ENDS -->
        
        <div class="container content">
            <div class="row">
            <div class=" col-sm-4 col-sm-offset-4">

                <!-- PANEL OPEN TO CONTAIN SIGN UP FORM -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4>Sign Up</h4>
                    </div>
                    <div class="panel-body">

                        <!-- SIGN UP FORM -->
                        <form method="POST" action="user_signup_script.php">
                        <!-- The form data is processed in the 'user_signup_script.php' page -->
                            <div class="form-group">
                                <label for="name">Name:</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Name" required="true">
                            </div>

                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Enter Valid Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required="true">
                            </div>

                            <div class="form-group">
                                <label for="password">Password:</label> 
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password (Min. 6 characters)" required="true">
                            </div> <!-- The minimum password length of 6 characters is validated in user_signup_script.php -->

                            <div class="form-group">
                                <label for="phone">Phone number:</label>
                                <input type="number" class="form-control" id="phone" name="phone" placeholder="Enter Valid Phone number (Ex: 8448448556)" required="true">
                            </div>

                            <button type="submit" class="button btn-block" name="register">Sign Up</button>
                        </form>
                        <!-- SIGN UP FORM ENDS -->
                    </div>
                </div>
                <!-- PANEL CONTAINING SIGN UP FORM ENDS -->
            </div>
        </div>
        </div>
        
        <!-- FOOTER SECTION -->
        <div class="footer">
            <?php
            include'footer.php';
            ?>  
        </div>
        <!-- FOOTER SECTION ENDS  -->

    </body>
</html>

<?php } ?>