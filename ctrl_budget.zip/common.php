<?php
session_start();
$con=mysqli_connect("localhost","root","","ctrlbudget","3306") or die(mysqli_error($con));
?>

