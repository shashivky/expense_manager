<?php
include'common.php';
//Ensuring the user is logged in and the session variable is set,else the user is redirected to user home page
if (isset($_SESSION['user'])) {

    //Selecting initial budget and number of people added in plan from 'plan' table 
    $select_bdgt_query = "SELECT in_bdgt,num_people,title FROM plan WHERE plan_id='" . $_SESSION['plan_id'] . "' Limit 1";
    $select_bdgt_query_result = mysqli_query($con, $select_bdgt_query);
    $plan_array = mysqli_fetch_array($select_bdgt_query_result);

    //Saving the values in suitable variables
    $initial_budget = $plan_array['in_bdgt']; //Also used to calculate remaining budget
    $num_people = $plan_array['num_people']; //Also used to calculate individual shares
    $title = $plan_array['title'];

    $num_bdgt = mysqli_num_rows($select_bdgt_query_result);

    //Select query to fetch details of the person and respective contribution in expense from 'expense' table
    $select_person_query = "SELECT person,exp_amt from expense where plan_id='" . $_SESSION['plan_id'] . "'";
    $select_person_query_result = mysqli_query($con, $select_person_query);

    //Number of rows corresponds to the number of people contributing to the expense
    $num_rows_exp = mysqli_num_rows($select_person_query_result);

    //Adding up individual contribution in expense and hence calculating total amount spent by the user 
    $total_amt_spent = 0;
    for ($i = 1; $i <= $num_rows_exp; $i++) {
        $expense = mysqli_fetch_array($select_person_query_result);
        $spent_amt = $expense['exp_amt'];
        $total_amt_spent = $total_amt_spent + $spent_amt;
    }

    //Calculation of remaining amount
    $remaining_amt = $initial_budget - $total_amt_spent;
    $remaining_amt = number_format((float) $remaining_amt, 2, '.', '');

    //Calculation of overspent amount
    $overspent_amt = -$remaining_amt;
    $overspent_amt = number_format((float) $overspent_amt, 2, '.', '');

    //Calculation of individual share
    $inv_share = ($total_amt_spent / $num_people);
    $inv_share = number_format((float) $inv_share, 2, '.', '');

    //Selecting expense distribution details from the database 
    //These details are displayed in the expense distribution panel
    $select_name_query = "SELECT exp_dis_id,name_person,exp_db_amt from exp_dbution where plan_id='" . $_SESSION['plan_id'] . "'";
    $select_name_query_result = mysqli_query($con, $select_name_query);

    //The details are saved in an array to be used multiple times
    $results = array();
    while ($row = mysqli_fetch_array($select_name_query_result)) {
        $results[] = $row;
    }
} else {
    echo "<script>location.href='user_index.php'</script>";
}

//Redirecting the user to view plan page on the click of 'GO BACK' button
If (isset($_POST['go_back'])) {
    echo"<script>location.href='view_plan_page.php'</script>";
}
?>


<!doctype html>
<!-- This page can be accessed only by LOGGED IN users -->
<html>
    <head>
        <title>Expense distribution | Ct₹l Budget</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/exp_distribution.css">
        <style>
            #remain{
                <?php if ($remaining_amt < 0) { ?>
                    color:red;
                    float:right;
                <?php } ?>
                <?php if ($remaining_amt > 0) { ?>
                    color:green;
                    float:right;
                <?php } ?>
                <?php if ($remaining_amt == 0) { ?>
                    color:black;
                    float:right;
                <?php } ?>  
            }
        </style>
    </head>
    <body>
        <?php
        include'navbar_home.php';
        ?>
        <!-- EXPENSE DISTRIBUTION SECTION BEGINS -->
        <!-- In this section, the expense distribution among the various persons added by the user through 'add expense form' is displayed. 
        -->
        <div class="container content">
            <div class="row">
                <div class="col-xs-12 col-xs-offset-0 col-sm-6 col-sm-offset-3">
                    <div class="panel">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-8 col-xs-offset-1"><h4><?php echo $title; ?></h4></div>
                                <div class="col-xs-3"><h4 style="float:right;"><span class="glyphicon glyphicon-user"></span> <?php echo $num_people; ?></h4></div>
                            </div>
                        </div>   
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-6 data"><p>Initial budget</p></div>
                                <div class="col-xs-6"><p class="value"><b><span>&#8377</span> <?php echo $initial_budget; ?></b></p></div>
                            </div>
                            <div class="row">
                                <?php foreach ($results as $key => $row) { ?>
                                    <div class="col-xs-8 data"><p><?php echo $row['name_person']; ?></p></div>
                                    <div class="col-xs-4"><p class="value"><span>&#8377</span> <?php echo $row['exp_db_amt']; ?></p></div>
                                <?php } ?>

                            </div>
                            <div class="row">
                                <div class="col-xs-8 data"><p>Total amount spent</p></div>
                                <div class="col-xs-4"><p class="value"><b><span>&#8377</span> <?php echo $total_amt_spent; ?></b></p></div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4 data"><p>Remaining Amount</p></div>
                                <div class="col-xs-8">
                                    <?php if ($remaining_amt < 0) { ?>
                                        <p id="remain">Overspent by <span>&#8377</span> <?php echo $overspent_amt; ?></p>
                                    <?php } ?>
                                    <?php if ($remaining_amt > 0) { ?>
                                        <p id="remain"><span>&#8377</span> <?php echo $remaining_amt; ?></p>
                                    <?php } ?>
                                    <?php if ($remaining_amt == 0) { ?>
                                        <p id="remain"><span>&#8377</span> <?php echo $remaining_amt; ?></p>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-8 data"><p>Individual Share</p></div>
                                <div class="col-xs-4"><p class="value"><span>&#8377</span> <?php
                                        if ($inv_share == NULL) {
                                            echo "0";
                                        } else {
                                            echo $inv_share;
                                        }
                                        ?></p></div>
                            </div>
                            <div class="row">
                                <?php foreach ($results as $key => $row) { ?>
                                    <div class="col-xs-6 data"><p><?php echo $row['name_person']; ?></p></div>
                                    <div class="col-xs-6"> <?php
                                        $share = $row['exp_db_amt'] - $inv_share;
                                        if ($share == NULL) {
                                            ?>
                                            <p class="value"><span>&#8377</span> 0</p>
                                        <?php } elseif ($share > 0) { ?>
                                            <p id="get_back_amount"> Gets back <span>&#8377</span> <?php echo $share; ?></p>
                                        <?php } else { ?>
                                            <p id="owe_amount">Owes <span>&#8377</span> <?php echo -$share; ?> </p>
                                        <?php } ?>
                                    </div>
                                <?php } ?>
                            </div><br>

                            <center><form action="" method="POST"><button class="button" name="go_back"><span class="glyphicon glyphicon-arrow-left"></span> Go back</button></form></center>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <?php
            include'footer.php';
            ?>
        </div>


    </body>
</html>

