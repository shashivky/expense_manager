<?php

include'common.php';
if (isset($_POST['login'])) {

    //Fetching user's input from the login form and storing them in suitable variables
    $email = $_POST['email'];
    $pwd = $_POST['password'];

    $regex_em = "/^[_a-z0-9]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/";

    //Generating the error messages if the email or password do not match the required pattern
    if (!preg_match($regex_em, $email)) {
        echo"<script>alert('Please enter correct Email id and Password')</script>";
        echo"<script>location.href='user_login.php'</script>";
    } else {
        $pwd = md5(md5($pwd));
        $select_query = "SELECT user_id,email, password FROM users where email='" . $email . "' AND password='" . $pwd . "' limit 1";
        $select_query_result = mysqli_query($con, $select_query);
        $num_rows = mysqli_num_rows($select_query_result);
        
        /*if the number of rows is exactly 1 corresponding to the inputs of user in the login form, the user is allowed to login
          else he is shown the error message*/
        if ($num_rows == 1) {
            $user_data = mysqli_fetch_array($select_query_result);
            $user_id = $user_data['user_id'];

            /*user_id from the user table corresponding to user's details is saved as session variable to identify the user throughtout the session
             */
            $_SESSION['user'] = $user_id;//SESSION VARIABLE is set as IDENTITY OF USER

            echo"<script>location.href='user_home.php'</script>";//On successful login, user is redirected to home page
        } else {
            echo"<script>alert('Please enter correct Email id and Password')</script>";
            echo"<script>location.href='user_login.php'</script>";
        }
    }
}
?>

