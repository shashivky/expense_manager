<?php
include'common.php';

//Ensuring the user is LOGGED IN to access the page
//Session Variables 'budget' and 'people' are retrieved from 'create plan' form and are used in this page
if (!isset($_SESSION['user']) or ! isset($_SESSION['budget']) or ! isset($_SESSION['people'])) {
    echo"<script>location.href='user_index.php'</script>";
} else {
    ?>
    <!doctype html>
    <!--This page can be accessed only by LOGGED IN users-->
    <html>
        <head>
            <title>Plan details| Ct₹l Budget</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
            <link rel="stylesheet" type="text/css" href="css/plan_details.css">
        </head>
        <body>
            <!-- NAVIGATION BAR SECTION -->
            <div><?php
                include'navbar_home.php';
                ?></div>
            <!-- NAVIGATION BAR SECTION ENDS-->
            
            <div class="container content">
                <div class="row">
                    <div class="col-sm-6 col-sm-offset-3 col-xs-12 col-xs-offset-0">

                        <!-- PANEL OPEN TO CONTAIN PLAN DETAILS FORM-->
                        <div class="panel">
                            <div class="panel-body">

                                <!--PLAN DETAILS FORM-->
                                <!--The input into plan details form is processed in 'plan_details_script.php'-->
                                <form method="POST" action="plan_details_script.php">

                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" class="form-control" id="title" name="title" required="true" placeholder="Enter Title (Ex:Trip to Goa)">
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-xs-6"><label for="from">From</label>
                                            <input type="date" class="form-control" id="from" name="from" required="true">
                                        </div>  
                                        <div class="col-xs-6">
                                            <label for="to">To</label>
                                            <input type="date" class="form-control" id="to" name="to" required="true"></div>
                                    </div>

                                    <div class="form-group row">
                                        <div class="col-sm-8">
                                            <label for="ini_bdgt">Initial budget</label>
                                            <input type="number" class="form-control" id="ini_bdgt" name="ini_bdgt" disabled value="<?php echo $_SESSION['budget']; ?>"></div>

                                        <div class="col-sm-4"><label for="num_people">No. of People</label>
                                            <input type="number" class="form-control" id="num_people" name="num_people" required="true" disabled value="<?php echo $_SESSION['people']; ?>"></div>

                                    </div>
                                    <?php
                                    $limit = $_SESSION['people'];
                                    $counter = 1;
                                    while ($counter <= $limit) {
                                        echo "<div class=\"form-group\"><label for=\"person$counter\">Person $counter:</label>"
                                        . "<input type=\"text\" class=\"form-control\" name=\"person[]\" id=\"person$counter\" placeholder=\"Person $counter Name\" ></div>";
                                        $counter++;
                                    }
                                    ?>
                                    <button type="submit" class="btn-block button1" name="add">SUBMIT</button>

                                </form>
                                <!--PLAN DETAILS FORM ENDS-->
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
            <!--FOOTER SECTION -->
            <div class="footer">
                <?php
                include'footer.php';
                ?>
            </div>
            <!--FOOTER SECTION ENDS -->
        </body>
    </html>

<?php } ?>